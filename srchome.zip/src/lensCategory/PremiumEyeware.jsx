import React from 'react'
import premium from "../assets/images/Screenshot (18).png"
import asSoonAsDesk from "../assets/images/As seen on Desk.webp"
import moniRoi from "../assets/images/Screenshot (19).png"
import mouniRai from "../assets/images/mouniRoi.webp"
import sharkTank from "../assets/images/Screenshot (20).png"
import shark from "../assets/images/Homepage-Banner-web.webp"

import webBanner from "../assets/images/Screenshot (21).png"
import karan from "../assets/images/Web_banner.webp"
import trendingSpecs from "../assets/images/Screenshot (22).png"
import sunBannerWeb from "../assets/images/Sun-Banner-web.webp"
import ojosWeb9 from "../assets/images/ojos-web-1199.webp"
import ss24 from "../assets/images/Screenshot (24).png"
import ss25 from "../assets/images/Screenshot (25).png"
import refreshBanner from "../assets/images/Refresh-Banner-Web.webp"
import ss26 from "../assets/images/Screenshot (26).png"
import banner05 from "../assets/images/Banner05_Final2ndDec21.webp"
import whatsp from "../assets/images/whatsapp.webp"
const PremiumEyeware = () => {
  return (
    <div>
        <img src={premium} alt="" />
        <img src={asSoonAsDesk} alt="" />
        <img src={moniRoi} alt="" />
        <img src={mouniRai} alt="" />
        <img src={sharkTank} alt="" />
        <img src={shark} alt="" />
        <img src={webBanner} alt="" />
        <img src={karan} alt="" />
        <img src={trendingSpecs} alt="" />
        <img src={sunBannerWeb} alt="" />
        <img src={ss24} alt="" />
        <img src={ojosWeb9} alt="" />
        <img src={ss25} alt="" />
        <img src={refreshBanner} alt="" />
        <img src={ss26} alt="" />
        <img src={banner05} alt="" />
        <img className='mt-10' src={whatsp} alt="" />
    </div>
  )
}

export default PremiumEyeware